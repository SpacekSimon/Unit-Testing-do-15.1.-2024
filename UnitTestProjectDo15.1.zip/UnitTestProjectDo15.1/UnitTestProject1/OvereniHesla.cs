﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    internal class OvereniHesla
    {
        public static bool DelkaHesla(string heslo)
        {
            if (heslo.Length >= 8 && heslo.Length <= 20)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ObsahujeSlovoRPR(string heslo)
        {
            return heslo.Contains("RPR");
        }

        public static bool NeprazdneHeslo(string heslo)
        {
            if (heslo != "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
