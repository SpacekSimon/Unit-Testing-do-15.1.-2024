﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Activation;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    internal class HerniPostava
    {
        public string jmeno;

        public HerniPostava(string jmeno)
        {
            this.jmeno = jmeno;
        }

    }
}
